CREATE TABLE IF NOT EXISTS users (
    email VARCHAR,
    hash VARCHAR,
    prevConditions BLOB
);